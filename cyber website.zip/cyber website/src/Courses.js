import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import Nav from './Nav';
import Footer from './Footer';

const Courses = () => {
    return (
        <div>
            {/* Internal CSS for styling */}
            <style >{`
                .section-header {
                    text-align: left ;
                    padding: 20px;
                }

                .categories-contents {
                    display: flex;
                    flex-wrap: nowrap; /* Adjusted to prevent wrapping */
                    overflow-x: auto;
                    padding: 20px;
                    gap: 10px;
                }

                .category-item {
                    background-color: #f4f4f4;
                    border: 1px solid #ddd;
                    border-radius: 10px;
                    padding: 30px;
                    width: 200px;
                    text-align: center;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                    transition: transform 0.3s, box-shadow 0.3s;
                    flex-shrink: 0;
                }

                .category-item:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
                }

                .category-icon {
                    font-size: 40px;
                    margin-bottom: 10px;
                    color: #007bff;
                }

                .instructor-container {
                    background-color: #fafafa;
                    padding: 40px;
                    text-align: center;
                    margin: 20px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }

                .teacher-btn {
                    background-color: #007bff;
                    color: #fff;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 5px;
                    cursor: pointer;
                    transition: background-color 0.3s;
                }

                .teacher-btn:hover {
                    background-color: #0056b3;
                }

                .content-wrapper {
                    margin-top: 40px; /* Space between Nav and Courses */
                }
            `}</style>
            {/* Navbar Section */}
            <Nav />
            {/* Content Wrapper to add space between Nav and the rest of the content */}
            <div className="content-wrapper">
                {/* Courses Categories Section */}
                <div className="categories">
                    {/* Categories Section Header */}
                    <header className="section-header">
                        <h1>Cyber Security Courses</h1>
                        <p>Explore our diverse range of cyber courses tailored to meet your learning needs.</p>
                    </header>
                    {/* Categories Section Contents */}
                    <div className="categories-contents">
                        <div className="category-item">
                            <div className="category-icon">
                                <i className="fa-solid fa-palette"></i>
                            </div>
                            <div className="category-desc">
                                <h3>Designing</h3>
                                <p>Master the art of designing in the cyber world with our specialized courses.</p>
                            </div>
                        </div>
                        <div className="category-item">
                            <div className="category-icon">
                                <i className="fa-solid fa-code"></i>
                            </div>
                            <div className="category-desc">
                                <h3>Development</h3>
                                <p>Enhance your development skills with our cutting-edge cyber development courses.</p>
                            </div>
                        </div>
                        <div className="category-item">
                            <div className="category-icon">
                                <i className="fa-solid fa-bullhorn"></i>
                            </div>
                            <div className="category-desc">
                                <h3>Marketing</h3>
                                <p>Learn how to market cybersecurity solutions effectively with our marketing courses.</p>
                            </div>
                        </div>
                        <div className="category-item">
                            <div className="category-icon">
                                <i className="fa-solid fa-camera"></i>
                            </div>
                            <div className="category-desc">
                                <h3>Photography</h3>
                                <p>Discover how photography plays a crucial role in the cyber domain with our photography courses.</p>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Teacher Section */}
                <section className="instructor">
                    <div className="instructor-container">
                        <h2>Become an instructor with Cyber Security Institute</h2>
                        <p>Are you passionate about cybersecurity? Join us as an instructor at Cyber Security Institute and contribute to shaping the next generation of cybersecurity professionals. Share your expertise with our students and help them excel in their cybersecurity careers.</p>
                        <button className="teacher-btn btn">Your Details</button>
                    </div>
                </section>
            </div>
            {/* Footer */}
            <Footer />
        </div>
    );
}

export default Courses;
