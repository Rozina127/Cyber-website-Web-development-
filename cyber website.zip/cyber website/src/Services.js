import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import Nav from './Nav';
import Footer from './Footer';

const Services = () => {
    const [hoverIndex, setHoverIndex] = useState(null);

    return (
        <section style={styles.services} id="services">
            <Nav />
            <div style={styles.contentWrapper}>
                {/* Services Header Starts */}
                <header style={styles.sectionHeader}>
                    <h1 style={styles.headerTitle}>Why Choose Us</h1>
                    <p style={styles.headerSubtitle}>Empower yourself with flexible learning options designed to fit your schedule.</p>
                </header>
                {/* Services Header Ends */}
                {/* Services Contents Starts */}
                <div style={styles.servicesContents}>
                    {serviceData.map((service, index) => (
                        <Link
                            to={service.link}
                            key={index}
                            style={hoverIndex === index ? { ...styles.serviceBox, ...styles.serviceBoxHover } : styles.serviceBox}
                            onMouseEnter={() => setHoverIndex(index)}
                            onMouseLeave={() => setHoverIndex(null)}
                        >
                            <div style={styles.serviceIcon}>
                                <i className={service.icon} style={styles.icon}></i>
                            </div>
                            <div style={styles.serviceDesc}>
                                <h2 style={styles.serviceTitle}>{service.title}</h2>
                                <p style={styles.serviceText}>{service.text}</p>
                            </div>
                        </Link>
                    ))}
                </div>
                {/* Services Contents Ends */}
            </div>
            <Footer />
        </section>
    );
};

const serviceData = [
    {
        link: "/flexible-timing",
        icon: "fa-solid fa-calendar",
        title: "Flexible Timing",
        text: "Our courses offer flexible timing options, allowing you to learn at your own pace and convenience."
    },
    {
        link: "/expert-teachers",
        icon: "fa-solid fa-users",
        title: "Expert Teachers",
        text: "Our team consists of experienced and knowledgeable teachers who are dedicated to helping you succeed."
    },
    {
        link: "/live-support",
        icon: "fa-solid fa-clock",
        title: "24/7 Live Support",
        text: "We provide round-the-clock live support to assist you with any questions or concerns you may have."
    }
];

const styles = {
    services: {
        padding: '20px',
        backgroundColor: '#f9f9f9',
    },
    contentWrapper: {
        marginTop: '40px', // Add space between Nav and the content
        marginBottom: '30px', // Add space between Services content and the Footer
    },
    sectionHeader: {
        textAlign: 'center',
        marginBottom: '40px',
    },
    headerTitle: {
        fontSize: '36px',
        color: '#333',
        marginBottom: '10px',
    },
    headerSubtitle: {
        fontSize: '18px',
        color: '#777',
    },
    servicesContents: {
        display: 'flex',
        justifyContent: 'space-around',
        flexWrap: 'wrap',
    },
    serviceBox: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        width: '300px',
        padding: '20px',
        margin: '10px',
        backgroundColor: '#fff',
        borderRadius: '10px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
        textDecoration: 'none',
        color: '#333',
        textAlign: 'center',
        transition: 'transform 0.3s',
    },
    serviceBoxHover: {
        transform: 'scale(1.05)',
    },
    serviceIcon: {
        fontSize: '40px',
        marginBottom: '30px',
        color: '#007BFF', // Set the color of the icons
    },
    icon: {
        color: 'black', // Set the color of the icons
    },
    serviceDesc: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    serviceTitle: {
        fontSize: '24px',
        margin: '10px 0',
    },
    serviceText: {
        fontSize: '16px',
        color: '#555',
    },         
};

export default Services;