import React from 'react';

import { BrowserRouter, Routes, Route} from 'react-router-dom'; // Import Router and Route
import Nav from './Nav';
import Home from "./Home";
import Aboutus from './Aboutus';
import Partners from './Partners';
import Services from './Services';
import Courses from './Courses';
import Testmonials from './Testmonials'; // Corrected import statement
import Footer from './Footer';
import Signup from './Signup';
import Login from './Login';

function App() {
  return (
    <BrowserRouter>

      <div>
        {/* <Nav /> */}
    <Routes>
        {/* Use Route for each page */}
        <Route path="/" element={<Home/>} />
        <Route path="/about" element={<Aboutus/>} />
    
  
        <Route path="/partners" element={<Partners/>} />
        <Route path="/services" element={<Services/>} />
        <Route path="/courses" element={<Courses/>} />
        <Route path="/testmonials" element={<Testmonials/>} />  {/*Corrected path*/} 
        <Route path="/signup" element={<Signup/>} />
        <Route path="/login" element={<Login/>} /> 
    </Routes>
        {/* <Footer /> */}
      </div>
    </BrowserRouter>
  );
}

export default App;
