import React from 'react';
import Nav from './Nav';
import Footer from './Footer';
import './style.css'; // Assuming you have some common styles here

const Home = () => {
    return (
        <div className='Main_div'>
            <div style={styles.navContainer}>
                <Nav />
            </div>
            <div style={styles.mainContent}>
                <div style={styles.bannerDesc}>
                    <h2 style={styles.bannerTitle} className="hover-color">Start Learning With Our Security Experts, Anywhere, Anytime</h2>
                    <p style={styles.bannerText}>Empower yourself with our comprehensive cyber security courses taught by industry professionals.</p>
                    <form className="search-bar" style={styles.searchBar}>
                        <input type="search" placeholder="Search Your Course" style={styles.searchInput} />
                        <i className="fa-solid fa-search" style={styles.searchIcon}></i>
                    </form>
                </div>
                <div style={styles.bannerImg}>
                    <div style={styles.bannerImgContainer}>
                        <img src="images/img2.webp" alt="Banner" style={styles.bannerImage} />
                        <div style={styles.states}>
                            <div style={styles.totalCourses}>
                                <div style={styles.icon}>
                                    <i className="fa-solid fa-book" style={styles.iconFont}></i>
                                </div>
                                <div style={styles.desc}>
                                    <span style={styles.totalCoursesNumber}>284+</span>
                                    <span style={styles.totalCoursesText}>Total Courses</span>
                                </div>
                            </div>
                            <div style={styles.coursesRatings}>
                                <span style={styles.coursesRatingValue}>4.7<i className="fa-solid fa-star" style={styles.starIcon}></i></span>
                                <span style={styles.coursesRatingText}>Ratings (58k)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style={styles.footerContainer}>
                <Footer />
            </div>
        </div>
    );
}

const styles = {
    navContainer: {
        backgroundColor: '#1a1a1a', // Different background color for Nav
        padding: '10px 0',
    },
    mainContent: {
        backgroundColor: 'black',
        display: 'flex',
        flexDirection: 'row',
        padding: '50px',
        alignItems: 'center',
        justifyContent: 'center',
    },
    bannerDesc: {
        alignItems: 'center',
        justifyContent: 'center',
        color: '#fff',
        position: 'relative',
        flexBasis: '50%',
        maxWidth: '700px',
        zIndex: '2',
    },
    bannerTitle: {
        color: '#fff',
        fontSize: '48px',
        letterSpacing: '1px',
        lineHeight: '1.4',
        marginBottom: '10px',
        transition: 'color 0.3s ease-in-out',
    },
    bannerText: {
        color: '#fff',
        lineHeight: '1.4',
        marginBottom: '50px',
    },
    searchBar: {
        position: 'relative',
        width: '400px',
        height: '50px',
        display: 'flex',
        alignItems: 'center',
        overflow: 'hidden',
    },
    searchInput: {
        width: '100%',
        height: '100%',
        padding: '0px 60px 0px 10px',
        fontSize: '17px',
        letterSpacing: '1px',
        backgroundColor: '#ccc',
        color: '#333',
        border: '2px solid #c1dbcc',
        borderRadius: '5px',
        outlineColor: 'var(--primary-clr)',
    },
    searchIcon: {
        position: 'absolute',
        height: '100%',
        width: '50px',
        backgroundColor: '#000',
        right: '0',
        color: '#fff',
        borderRadius: '0px 5px 5px 0px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        cursor: 'pointer',
    },
    bannerImg: {
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        flexBasis: '50%',
        display: 'flex',
        justifyContent: 'flex-end',
        zIndex: '1',
    },
    bannerImgContainer: {
        position: 'relative',
        width: '400px',
        zIndex: '2',
    },
    bannerImage: {
        width: '100%',
        borderRadius: '5px',
    },
    states: {
        position: 'absolute',
        width: '100%',
        height: '100%',
        top: '0',
        left: '0',
    },
    totalCourses: {
        position: 'absolute',
        padding: '6px 10px 6px 6px',
        backgroundColor: '#f0f0f0',
        borderRadius: '5px',
        bottom: '15%',
        left: '-80px',
        display: 'flex',
        alignItems: 'center',
        boxShadow: '0px 0px 15px 0px rgba(0,0,0,0.3)',
    },
    icon: {
        width: '50px',
        height: '50px',
        borderRadius: '50%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#000',
        marginRight: '7px',
    },
    iconFont: {
        fontSize: '22px',
        color: '#fff',
    },
    desc: {
        display: 'flex',
        flexDirection: 'column',
    },
    totalCoursesNumber: {
        fontSize: '24px',
        fontWeight: '600',
        letterSpacing: '1px',
        marginBottom: '2px',
    },
    totalCoursesText: {
        fontSize: '14px',
        color: '#666',
    },
    coursesRatings: {
        position: 'absolute',
        width: '90px',
        height: '90px',
        padding: '10px',
        borderRadius: '50%',
        backgroundColor: '#f0f0f0',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        top: '80px',
        right: '5px',
        boxShadow: '0px 0px 15px 0px rgba(0,0,0,0.3)',
    },
    coursesRatingValue: {
        color: '#000',
        fontSize: '24px',
        fontWeight: '600',
        textAlign: 'center',
    },
    starIcon: {
        color: 'gold',
        fontSize: '14px',
    },
    coursesRatingText: {
        color: '#666',
        fontSize: '15px',
        textAlign: 'center',
    },
    footerContainer: {
        backgroundColor: '#1a1a1a', // Different background color for Footer
        padding: '10px 0',
    },
};

export default Home;