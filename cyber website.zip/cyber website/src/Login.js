import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Log.css'; // Assuming you have a CSS file named 'Log.css' for styles

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch('http://localhost/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: email, password }),
                credentials: 'include',
            });
            const data = await response.text();
            alert(data);
            if (data === 'Login Successful') {
                navigate('/');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div className='bg-image'>
            <div className="Main-Container">
                <div className="LogIn-Box">
                    <h1 className="hd1">LogIn!!!</h1>
                    <form onSubmit={handleLogin}>
                        <div className="Input">
                            <span className="icon"><ion-icon name="mail"></ion-icon></span>
                            <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                        </div>
                        <div className="Input">
                            <span className="icon"><ion-icon name="lock"></ion-icon></span>
                            <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                        </div>
                        <div className="Check">
                            <input type="checkbox" /> Remember me
                            <Link to="/forgot-password">Forgot Password</Link>
                        </div>
                        <button type="submit" className="btn">LogIn</button>
                        <div className="Register">
                            Dont have an account?
                            <Link to="/signup">Signup</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Login;
