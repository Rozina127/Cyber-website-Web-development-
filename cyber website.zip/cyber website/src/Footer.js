// Footer.js

import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import './style.css'; // Assuming you have a CSS file for styles

const Footer = () => {
    return (
        <section className="footer" id="footer">
            {/* Footer Contents */}
            <div className="footer-contents">
                <div className="footer-col footer-col-1">
                    <div className="col-title">
                        <img src="images/img1.jpg" alt="Logo" />
                    </div>
                    <div className="col-contents">
                        <p>Welcome to our Cybersecurity Community</p>
                        <p>Join us in our mission to promote cybersecurity awareness and education.</p>
                    </div>
                </div>
                <div className="footer-col footer-col-2">
                    <div className="col-title">
                        <h3>Contact</h3>
                    </div>
                    <div className="col-contents">
                        <div className="contact-row">
                            <span>Address</span>
                            <span>street 10 ,I8 Islamabad </span>
                        </div>
                        <div className="contact-row">
                            <span>Phone</span>
                            <span>+923235080987</span>
                        </div>
                        <div className="contact-row">
                            <span>Website</span>
                            <span>RozinaWali-Tutorials.com</span>
                        </div>
                        <div className="contact-row">
                            <span>Email</span>
                            <span>rozinawali@gmail.com-Tutorials.com</span>
                        </div>
                    </div>
                </div>
                <div className="footer-col footer-col-3">
                    <div className="col-title">
                        <h3>Quick Links</h3>
                    </div>
                    <div className="col-contents">
                        {/* Use Link components for routing */}
                        <Link to="/">Home</Link>
                        <Link to="/services">Services</Link>
                        <Link to="/courses">Courses</Link>
                        <Link to="/about-us">About Us</Link>
                        <Link to="/testimonials">Partners</Link>
                    </div>
                </div>
                <div className="footer-col footer-col-4">
                    <div className="col-title">
                        <h3>Newsletter</h3>
                    </div>
                    <div className="col-contents">
                        <form className="newsletter">
                            <input type="email" placeholder="Your Email" />
                            <button className="newsletter-btn btn" type="submit">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
            {/* Footer Contents Ends */}
            <div className="copy-rights">
                <p>Created By <b>Rozina Wali and M.Ibrahim </b></p>
            </div>
        </section>
    );
}

export default Footer;
