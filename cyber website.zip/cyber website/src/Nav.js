// Nav.js

import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import './style.css'; // Assuming you have a CSS file for styles

const Nav = () => {
    return (
        <section className="home" id="home">
            <nav className="main-navbar">
                <Link to="/" className="logo"> {/* Use Link component instead of <a> tag */}
                    <img src="images/img1.jpg" alt="Logo" width="6" height="3" />
                </Link>
                <ul className="nav-list">
                    <li><Link to="/">Home</Link></li> {/* Use Link component instead of <a> tag */}
                    <li><Link to="/about">About Us</Link></li> {/* Use Link component instead of <a> tag */}
                    <li><Link to="/partners">Partners</Link></li> {/* Use Link component instead of <a> tag */}
                    <li><Link to="/services">Services</Link></li> {/* Use Link component instead of <a> tag */}
                    <li><Link to="/courses">Courses</Link></li> {/* Use Link component instead of <a> tag */}
                   
                </ul>
                <Link to="/login" className="get-started-btn-container"> {/* Use Link component instead of <a> tag */}
                    <button className="get-started-btn btn">LOGIN</button>
                </Link>
                <div className="menu-btn">
                    <span></span>
                </div>
            </nav>
        </section>
    );
}

export default Nav;
