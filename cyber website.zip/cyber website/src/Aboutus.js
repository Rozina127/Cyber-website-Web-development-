import React from 'react';
import Nav from './Nav';
import Footer from './Footer';

const AboutUs = () => {
    return (
        <div style={styles.container}>
            <Nav />
            <div style={styles.mainContent}>
                <div style={styles.header}>
                    <h2 style={styles.title}>About Us</h2>
                </div>
                <div style={styles.content}>
                    <div style={styles.textContainer}>
                        <p style={styles.text}>
                            Welcome to Cyber Website, your go-to destination for comprehensive cyber security education. We are dedicated to empowering individuals with the knowledge and skills needed to thrive in the cyber security domain. Our mission is to provide flexible learning options and expert guidance to help you succeed in your cyber security journey.
                        </p>
                        <p style={styles.text}>
                            At Cyber Website, we believe that education is the key to combating cyber threats and building a safer digital world. Our team of experienced instructors is committed to delivering high-quality courses tailored to meet the diverse needs of our students. Whether you're a beginner or an experienced professional, we have the resources and support you need to excel in the field of cyber security.
                        </p>
                    </div>
                    <div style={styles.imageContainer}>
                        <img src="/images/download.jpg" alt="About Us" style={styles.image} />
                    </div>
                </div>
            </div>
            <Footer />
        </div>
    );
}

const styles = {
    container: {
        margin: '5px',
        padding: '20px',
        border: '5px solid #ccc',
        borderRadius: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    mainContent: {
        marginTop: '50px', // Add space between Nav and the main content
    },
    header: {
        marginBottom: '40px',
    },
    title: {
        fontSize: '32px',
        marginBottom: '30px', // Adjusted space between heading and blue line
        color: '#333',
        textAlign: 'center', // Center align the heading
    },
    content: 
    {
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
    },
    textContainer: {
        flex: 1,
        marginRight: '20px',
    },
    text: {
        fontSize: '16px',
        lineHeight: '1.8',
        color: '#555',
        textAlign: 'justify', // Justify align the text
    },
    imageContainer: {
        flex: 1,
        maxWidth: '300px', // Control the maximum width of the image container
    },

    image: {
        width: '100%',
        height: 'auto',
        borderRadius: '5px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
};

export default AboutUs;