import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Log.css'; // Assuming you have a CSS file named 'Log.css' for styles

const Signup = () => {
    const [firstname, setFirstname] = useState('');
    const [lastname, setLastname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [cpassword, setCpassword] = useState('');
    const navigate = useNavigate();

    const handleSignup = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch('http://localhost/signup', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firstname, lastname, username: email, password, cpassword }),
            });
            const data = await response.text();
            alert(data);
            if (data === 'Sign Up Successfully') {
                navigate('/login');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div className='bg-image'>

        <div className="Main-Container">
            <div className="SignUp-Box">
                <h1>SignUp!!!</h1>
                <form onSubmit={handleSignup}>
                    <div className="Input">
                        <span className="icon"><ion-icon name="person"></ion-icon></span>
                        <input type="text" placeholder="First Name" value={firstname} onChange={(e) => setFirstname(e.target.value)} required />
                    </div>
                    <div className="Input">
                        <span className="icon"><ion-icon name="person"></ion-icon></span>
                        <input type="text" placeholder="Last Name" value={lastname} onChange={(e) => setLastname(e.target.value)} required />
                    </div>
                    <div className="Input">
                        <span className="icon"><ion-icon name="mail"></ion-icon></span>
                        <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    </div>
                    <div className="Input">
                        <span className="icon"><ion-icon name="lock"></ion-icon></span>
                        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                    </div>
                    <div className="Input">
                        <span className="icon"><ion-icon name="lock"></ion-icon></span>
                        <input type="password" placeholder="Confirm Password" value={cpassword} onChange={(e) => setCpassword(e.target.value)} required />
                    </div>
                    <button type="submit" className="btn">SignUp</button>
                    <div className="Register">
                        Already have an account?
                        <Link to="/login">Login</Link>
                    </div>
                </form>
            </div>
        </div>
        </div>
    );
}
export default Signup;






