import React from 'react';
import { Link } from 'react-router-dom';
import OwlCarousel from 'react-owl-carousel';
import Nav from './Nav';
import Footer from './Footer';

const Partners = () => {
    return (
        <section style={styles.partnersSection}>
            <Nav />
            <div style={styles.contentWrapper}>
                <h3 style={styles.title}>Our Trusted Partners in Cyber Security</h3>
                <div style={styles.carouselWrapper}>
                    <OwlCarousel
                        className="owl-theme"
                        loop
                        margin={10}
                        nav={true} // Keep navigation arrows
                        dots={false} // Removed pagination circles
                        items={4}
                        autoplay
                        style={styles.carousel}
                    >
                        {partnerData.map((partner, index) => (
                            <div className="item" key={index} style={styles.item}>
                                <Link to={partner.link} className="brand-item" style={styles.link}>
                                    <img src={partner.imgSrc} alt={partner.name} style={styles.image} />
                                    <p style={styles.partnerName}>{partner.name}</p>
                                </Link>
                            </div>
                        ))}
                    </OwlCarousel>
                </div>
            </div>
            <Footer />
        </section>
    );
};

const styles = {
    partnersSection: {
        padding: '20px',
        backgroundColor: '#f9f9f9',
    },
    contentWrapper: {
        marginTop: '70px', // Adjust as needed
        marginBottom: '90px', // Adjust as needed
    },
    title: {
        textAlign: 'center',
        marginBottom: '80px', // Adjust as needed
        color: '#333',
        fontSize: '34px',
    },
    carouselWrapper: {
        marginBottom: '50px', // Add space between heading and carousel
    },
    carousel: {
        display: 'flex',
        justifyContent: 'center',
    },
    item: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        backgroundColor: '#fff',
        borderRadius: '10px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        transition: 'transform 0.3s ease',
    },
    link: {
        textDecoration: 'none',
        color: '#333',
    },
    image: {
        width: '100px',
        height: '100px',
        objectFit: 'cover',
        borderRadius: '50%',
        marginBottom: '10px',
    },
    partnerName: {
        textAlign: 'center',
        fontSize: '16px',
        margin: '0',
    },
};

const partnerData = [
    { name: 'Partner 1', link: '/partner1', imgSrc: './images/1.png' },
    { name: 'Partner 2', link: '/partner2', imgSrc: './images/2.jpg' },
    { name: 'Partner 3', link: '/partner3', imgSrc: './images/4.webp' },
    { name: 'Partner 4', link: '/partner4', imgSrc: './images/3.png' },
    { name: 'Partner 5', link: '/partner5', imgSrc: './images/5.png' },
];

export default Partners;