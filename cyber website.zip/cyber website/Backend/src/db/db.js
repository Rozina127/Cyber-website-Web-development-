// getting-started.js
const mongoose = require('mongoose');

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/user');
  console.log("Connection Successfull.")
}

mongoose.set('strictQuery', false);

const registerSchema = new mongoose.Schema({
  firstname:{ 
  type :String,
  // required : true,

  },          
  lastname : { 
    type :String,
    required : true,
    },
  username :{ 
    type :String,
    required : true,
    unique: true
    },
  password :{ 
    type :String,
    required : true
    },
  cpassword : { 
    type :String,
    }

}); 

const user= mongoose.model('user', registerSchema);

module.exports = user;