const LocalStrategy     = require('passport-local').Strategy;
const user              = require('./db/db')
exports.initializingPassport = (passport) => {
    passport.use(
      new LocalStrategy(async (username, password, done) => {
        try {
          const User = await user.findOne({ username });
          if (!User) {
            return done(null, false, { message: "Incorrect username" });
          }
          if (User.password !== password) {
            return done(null, false, { message: "Incorrect password" });
          }
          return done(null, User);
        } catch (err) {
          return done(err);
        }
      })
    );
  
    passport.serializeUser((user, done) => {
      done(null, user.id);
    });
  
    passport.deserializeUser(async (id, done) => {
      try {
        const User = await user.findById(id);
        done(null, User);
      } catch (err) {
        done(err, false, { message: "Unexpected error occurred" });
      }
    });
  };
  
