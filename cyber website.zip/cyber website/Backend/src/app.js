const express = require('express');
const flash = require('connect-flash');
const user = require('./db/db');
const db = require('./db/db');
const cors = require('cors');
const port = 80;
const passport = require('passport');
var bodyParser = require('body-parser');
const expressSession = require('express-session');
const { initializingPassport } = require('./passports');
initializingPassport(passport);
db();
const app = express();

// Update CORS configuration
const corsOptions = {
    origin: 'http://localhost:3000', // Specify your frontend's origin
    credentials: true, // Allow credentials (cookies, headers)
};

app.use(cors(corsOptions));
app.use(expressSession({ secret: 'secret', resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));

app.post('/login', passport.authenticate('local', { failWithError: true }), (req, res) => {
    res.send('Login Successful');
}, (err, req, res, next) => {
    if (err.message === 'Email Not exists') {
        return res.send('User does not exist');
    } else if (err.message === 'Incorrect Password') {
        return res.send('Incorrect password');
    } else {
        return res.send('Incorrect username or password');
    }
});

// Signup requests
app.post('/signup', async (req, res) => {
    try {
        const { firstname, lastname, username, password, cpassword } = req.body;

        if (password !== cpassword) {
            return res.send('Password does not match');
        }

        const existingUser = await user.findOne({ username });
        if (existingUser) {
            return res.send('Email Already Exists');
        }

        const newUser = new user({
            firstname,
            lastname,
            username,
            password,
        });

        await newUser.save();
        res.send('Sign Up Successfully');
    } catch (err) {
        console.log(err);
    }
});

// Listening to the server
app.listen(port, () => {
    console.log('Your app is running successfully on port', port);
});
